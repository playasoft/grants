<?php

use Faker\Generator as Faker;
use App\Models\Score;

$factory->define(Score::class, function (Faker $faker) 
{
    return [
        //
    ];
});
